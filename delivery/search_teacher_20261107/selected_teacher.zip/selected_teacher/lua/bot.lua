local side=wesnoth.current.side
local allied=false
for other=1,#wesnoth.sides do
    if side~=other and not wesnoth.sides.is_enemy(side,other) then allied=true end
end
local format=#wesnoth.sides==2 and 'duel' or allied and 'team2v2' or 'ffa4'
return wesnoth.dofile('~add-ons/selected_teacher/lua/'..format..'/bot.lua')
