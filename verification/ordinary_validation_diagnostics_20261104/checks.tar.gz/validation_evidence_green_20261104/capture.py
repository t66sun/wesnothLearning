from pathlib import Path
import json
root=Path('/home/tongshu/acceptance/bounded_loop_v6_strict_20261104/runs/bounded_loop')
output={}
for fmt in ['duel','ffa4','team2v2']:
    records={}
    for name in ['validation-000003','reward-reference-v000003']:
        schedule=json.loads((root/fmt/'schedules'/f'{name}.json').read_text())
        records.update({j['id']: dict(schedule=name,scheduled_phase=j['meta'].get('phase')) for j in schedule})
    missing=set(records)
    with (root/fmt/'jobs.jsonl').open() as stream:
        for line in stream:
            if line.startswith('{"id": "final-'): break
            outcome=json.loads(line); ident=outcome.get('id')
            if ident in missing:
                records[ident].update(status=outcome['status'], reward_diagnostics_count=(len(outcome['reward_diagnostics']) if 'reward_diagnostics' in outcome else None))
                missing.remove(ident)
                if not missing: break
    if missing: raise ValueError(sorted(missing))
    output[fmt]=records
Path('v3-job-evidence.json').write_text(json.dumps(output,indent=2)+'\n')

