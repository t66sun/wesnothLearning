exec(open('shape.py').read().split('for i,r in enumerate(rows):')[0])
from pathlib import Path
from time import perf_counter
from learning.sequences import read_raw_shards
def safe(value):
    if isinstance(value,dict):
        return lua.table_from({str(k):safe(v) for k,v in value.items()})
    if isinstance(value,(list,tuple)):
        return lua.table_from([safe(v) for v in value])
    return value
print('overflow compared', [diff(lua.eval(native.lua(row[k])),safe(row[k])) for row in rows for k in ('global','opponents','spatial','candidates')])
root=Path('/home/tongshu/acceptance/bc_v6_readiness_20261103/runs/bc_readiness/duel/data')
sample=read_raw_shards([root/'rollout-00036-duel-g2.jsonl.gz'],'duel')
for name,convert in [('serialize',lambda x:lua.eval(native.lua(x))),('separate-containers',safe)]:
    start=perf_counter(); n=0
    for row in sample:
        for k in ('global','opponents','spatial','candidates'):
            t=convert(row[k])
            if k=='candidates': n+=len(t)
    print(name,'rows',len(sample),'retained_candidates',n,'seconds',round(perf_counter()-start,6))

