import native
from lupa import LuaRuntime
from tests.v5.test_learning_core import _rows
from tests.v5 import helpers
rows=_rows(turns=2,decisions_per_turn=1)
real=rows[1]['spatial']['entities']
rows[1]['spatial']['entities']=[dict(real[i%len(real)], id='overflow-%d'%i) for i in range(128)]
rows[1]['candidates'][0]['actor']=dict(rows[1]['candidates'][0].get('actor') or real[0],id='direct-actor')
for row in rows: helpers.pad_candidates(row,128)
lua=LuaRuntime(unpack_returned_tuples=True)
diff=lua.eval("""function(a,b)
  local function compare(x,y,p)
    if type(x)~=type(y) then return p..' types '..type(x)..','..type(y) end
    if type(x)~='table' then if x~=y then return p..' values '..tostring(x)..','..tostring(y) end; return end
    for k,v in pairs(x) do local d=compare(v,y[k],p..'/'..tostring(k)); if d then return d end end
    for k,v in pairs(y) do if x[k]==nil then return p..' extra '..tostring(k) end end
  end
  return compare(a,b,'') or 'equal'
end""")
for i,r in enumerate(rows):
    for key in ('global','opponents','spatial','candidates'):
        a=lua.eval(native.lua(r[key])); b=lua.table_from(r[key],recursive=True)
        print('turn',i+1,key,diff(a,b))

