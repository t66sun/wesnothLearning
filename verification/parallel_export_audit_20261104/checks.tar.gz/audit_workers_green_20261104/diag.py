from unittest.mock import patch
from lupa import LuaRuntime as RealLua
from tests.v5.test_learning_core import _rows,AuditExportTests
from tests.v5 import helpers
from learning.sequences import attach_histories
from learning.sequence_parity import _ParityAudit
from learning.model import batch as actual_batch
import native
class WrappedLua:
    def __init__(self, *args, **kwargs): self.real=RealLua(*args,**kwargs)
    def __getattr__(self,k): return getattr(self.real,k)
    def table_from(self, value, recursive=False):
        if recursive and mode=='text': return self.real.eval(native.lua(value))
        return self.real.table_from(value,recursive=recursive)
with helpers.temporary_directory() as d:
    model=AuditExportTests()._checkpoint_model(d)
    rows=_rows(turns=2,decisions_per_turn=1)
    real=rows[1]['spatial']['entities']
    rows[1]['spatial']['entities']=[dict(real[i%len(real)], id='overflow-%d'%i) for i in range(128)]
    rows[1]['candidates'][0]['actor']=dict(rows[1]['candidates'][0].get('actor') or real[0],id='direct-actor')
    for row in rows: helpers.pad_candidates(row,128)
    rows=attach_histories(rows)
    for mode in ['text','direct']:
        for caching in [False,True]:
            def call(*args,**kwargs):
                if not caching: kwargs.pop('history_cache',None)
                return actual_batch(*args,**kwargs)
            with patch('lupa.LuaRuntime',WrappedLua),patch('learning.sequence_parity.batch',call):
                print(mode,caching,_ParityAudit(model).measure(rows),flush=True)

