from pathlib import Path
from learning.sequences import read_raw_shards
from learning.sequence_parity import _same_inputs, _sequence_file_groups
root=Path('/home/tongshu/acceptance/bc_v6_readiness_20261103/runs/bc_readiness/duel/data')
paths=sorted(root.glob('rollout-00036-duel-g*.jsonl.gz'))
for group in _sequence_file_groups(paths):
    data=read_raw_shards(group,'duel')
    policy=[r for r in data if r['source']=='policy']
    dagger=[r for r in data if r['source']=='astra']
    print(group[0].name, len(policy),len(dagger),'equal',_same_inputs(policy,dagger))

