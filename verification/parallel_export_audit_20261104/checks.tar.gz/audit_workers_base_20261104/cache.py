import copy
from pathlib import Path
from time import perf_counter
import torch
from learning.export import load_model
from learning.model import batch
from learning.sequences import read_raw_shards
root=Path('/home/tongshu/acceptance/bc_v6_readiness_20261103/runs/bc_readiness/duel')
rows=read_raw_shards([root/'data/rollout-00036-duel-g2.jsonl.gz'],'duel')
model=load_model(root/'last_bc.pt','duel')[0].cpu().double().eval()
outputs={}
with torch.no_grad():
    for name, cache in [('uncached',None),('per-sequence',{})]:
        start=perf_counter()
        outputs[name]=[model(*batch([row],dtype=torch.float64,history_cache=cache)) for row in rows]
        print(name,'rows',len(rows),'seconds',round(perf_counter()-start,6))
max_delta=max((x-y).abs().max().item() for a,b in zip(outputs['uncached'],outputs['per-sequence']) for x,y in zip(a,b))
print('maximum_output_difference',max_delta)

