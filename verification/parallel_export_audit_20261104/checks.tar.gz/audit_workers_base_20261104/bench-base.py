from pathlib import Path
from learning.export import load_model, verify_numerics
from learning.sequences import read_raw_shards
run = Path('/home/tongshu/acceptance/bc_v6_readiness_20261103/runs/bc_readiness/duel')
paths = sorted((run / 'data').glob('rollout-00036-duel-g*.jsonl.gz'))
model, _ = load_model(run / 'last_bc.pt', 'duel')
rows = read_raw_shards(paths, 'duel')
print('files', len(paths), 'rows', len(rows), flush=True)
print('maximum_error', verify_numerics(model, rows), flush=True)

