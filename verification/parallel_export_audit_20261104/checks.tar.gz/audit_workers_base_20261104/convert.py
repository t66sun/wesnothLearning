from pathlib import Path
from time import perf_counter
from lupa import LuaRuntime
from learning.sequences import read_raw_shards
import native
root=Path('/home/tongshu/acceptance/bc_v6_readiness_20261103/runs/bc_readiness/duel/data')
rows=read_raw_shards([root/'rollout-00036-duel-g2.jsonl.gz'],'duel')
lua=LuaRuntime(unpack_returned_tuples=True)
for name, convert in [('serialize-parse',lambda x:lua.eval(native.lua(x))),('recursive-table',lambda x:lua.table_from(x,recursive=True))]:
    start=perf_counter()
    candidate_total=0
    for row in rows:
        for k in ('global','opponents','spatial','candidates'):
            t=convert(row[k])
            if k=='candidates': candidate_total+=len(t)
    print(name,'rows',len(rows),'retained_candidates',candidate_total,'seconds',round(perf_counter()-start,6))

