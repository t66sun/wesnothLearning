#!/usr/bin/env bash
trap 'status=$?; printf "%s\n" "$status" > "/home/tongshu/acceptance/ppo-transfer-361-20261115-MjHy2d/freeze/launcher.exit"' EXIT
set -eu
b=/home/tongshu/acceptance
s=$b/ppo306_20261108_Miwoyq/source
c=$b/ppo-diagnosis-20261115-Z8O0k3/capture
m=$b/ppo-mode-interaction-20261115-sgUXX6/freeze
h=$b/ppo-v38-20261115-8dIsba/formal
p=/home/tongshu/venv/bin/python
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
export WESNOTH_RULES_DIR=$b/filters_compiled_20261103/data/rules/1.18.8-combat-filtered
export PYTHONPATH=$s:/home/tongshu/myDev/wesnothLearning/formal_30h_scratch_20261104_2041/source/.extension
cd "$s"
a=/home/tongshu/acceptance/ppo-transfer-361-20261115-MjHy2d
d=$a/freeze
script=$a/verification/ppo_transfer_20261115/transfer.py
export PYTHONPATH=$PYTHONPATH:$a/verification/ppo_diagnosis_20261115
timeout --signal=TERM --kill-after=5s 1795 "$p" -u "$script" run "$d" e54e4009326b583e872705c27b3b18db7ef579a7d0e05f1abb017fb74810ef76
