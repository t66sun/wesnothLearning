#!/usr/bin/env bash
trap 'status=$?; printf "%s\n" "$status" > "/home/tongshu/acceptance/ppo-headroom-corrected-20261115-5Cxqxd/proof/proof-launcher.exit"' EXIT
set -eu -o pipefail
base=/home/tongshu/acceptance
capture="$base/ppo-diagnosis-20261115-Z8O0k3/capture"
source="$base/ppo306_20261108_Miwoyq/source"
extension=/home/tongshu/myDev/wesnothLearning/formal_30h_scratch_20261104_2041/source/.extension
python=/home/tongshu/venv/bin/python
audit=/home/tongshu/acceptance/ppo-headroom-corrected-20261115-5Cxqxd
export WESNOTH_RULES_DIR="$base/filters_compiled_20261103/data/rules/1.18.8-combat-filtered"
export PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONPATH="$source:$extension:$audit/verification/ppo_diag_capture_20261115:$audit/verification/ppo_diagnosis_20261115"
cd "$source"
timeout --signal=TERM --kill-after=5s 235 "$python" -u "$audit/verification/ppo_action_headroom_20261115/proof.py" prove "$capture" "$audit/proof" 4d66d5e357d84821abd239816c7577c0bc4bca94876c4ef819502d34253d4a26
