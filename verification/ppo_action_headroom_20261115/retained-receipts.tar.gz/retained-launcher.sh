#!/usr/bin/env bash
trap 'status=$?; printf "%s\n" "$status" > "/home/tongshu/acceptance/ppo-headroom-retained-20261115-g8a6CF/main/retained-launcher.exit"' EXIT
set -eu -o pipefail
base=/home/tongshu/acceptance
capture="$base/ppo-diagnosis-20261115-Z8O0k3/capture"
source="$base/ppo306_20261108_Miwoyq/source"
extension=/home/tongshu/myDev/wesnothLearning/formal_30h_scratch_20261104_2041/source/.extension
python=/home/tongshu/venv/bin/python
audit=/home/tongshu/acceptance/ppo-headroom-retained-20261115-g8a6CF
export WESNOTH_RULES_DIR="$base/filters_compiled_20261103/data/rules/1.18.8-combat-filtered"
export PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONPATH="$source:$extension:$audit/verification/ppo_diag_capture_20261115:$audit/verification/ppo_diagnosis_20261115"
cd "$source"
timeout --signal=TERM --kill-after=5s 655 "$python" -u "$audit/verification/ppo_action_headroom_20261115/retained.py" run "$capture" "$audit/main" 868aaea15d6a97381d9112a29e3acaaae9a828afc38fb26ffef230175a602403
