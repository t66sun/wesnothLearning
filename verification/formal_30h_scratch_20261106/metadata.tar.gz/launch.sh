#!/bin/bash
set -eu
root=/home/tongshu/myDev/wesnothLearning/formal_30h_scratch_20261104_2041
cd "$root/source"
export PYTHONPATH="$PWD/.extension:$PWD:$PWD/vendor/arena"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export SOURCE_COMMIT="$(cat "$root/SOURCE_COMMIT")"
export WESNOTH_EXE=/home/tongshu/myDev/wesnothLearning/WesnothLearning/.runtime/install/bin/wesnoth
date -Ins > "$root/started.txt"
rc=0
/home/tongshu/venv/bin/python -u -m learning run --run-dir runs/formal_30h_scratch --engine lite --evaluation-engine lite --formats duel ffa4 team2v2 --bc-games 300 600 400 --native-bc-games 0 0 0 --training-max-turns 60 --device cpu --workers 8 --trainer-threads 1 --hours 30 --final-holdout-hours 4 --wesnoth "$WESNOTH_EXE" > "$root/training.log" 2>&1 &
pid=$!
echo "$pid" > "$root/coordinator.pid"
wait "$pid" || rc=$?
date -Ins > "$root/finished.txt"
printf '%s\n' "$rc" > "$root/exit.code"
exit "$rc"
