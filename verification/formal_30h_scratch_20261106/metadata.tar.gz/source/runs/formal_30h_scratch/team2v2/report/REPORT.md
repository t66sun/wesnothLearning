# team2v2
Conclusion: not_passed
Blockers: gpt6astra: not_passed

| Control | Complete blocks | Planned blocks | Distinct scenarios | Required scenarios | Fault games | Difference | 95% interval | Status |
|---|---:|---:|---:|---:|---:|---:|---|---|
| gpt6astra | 30 | 30 | 15 | 12 | 0 | -0.5125 | [-0.8375, -0.2] | not_passed |
| ↳ astra_partner | 30 | | 15 | | | -0.2750 | [-0.625, 0.05] | |
| ↳ self_team | 30 | | 15 | | | -0.7500 | [-1.25, -0.2] | |

Selected: champion, v100; parameters: 776178
BC gate complete: True; clean teacher games: 400/400
Checkpoint SHA-256: 02de100f80960c93450e491fc4b72d6094bd4702fcb4bb9efadabcf1ab560993

Evaluation engine: lite
Evaluation scope: lite Astra comparison only; not native Wesnoth playing strength

## Trend

Panel sampled every 10 updates.

| Batch | Method | Updates | Elapsed hours | Loss |
|---|---|---:|---:|---:|
| 1 | bc | 40 | 0.1559342321422365 | 2.76682799718692 |
| 40 | bc | 60 | 3.639412000046836 | 0.7089391807160913 |
| 46 | bc | 60 | 4.121363984545072 | 0.6313585111570622 |
| 64 | ppo | 20 | 5.580280018978649 | -0.03467991046491079 |
| 88 | ppo | 10 | 7.475633691416847 | 0.11306088605197147 |
| 96 | ppo | 10 | 8.11786997841464 | 0.10680164967488963 |
| 97 | ppo | 10 | 8.218843404319552 | 0.06181702154572122 |
| 101 | ppo | 20 | 8.813845161133342 | 0.025112860695662674 |
| 112 | ppo | 10 | 9.857523043354352 | 0.042640054707590025 |
| 145 | ppo | 10 | 12.667665449579557 | -0.00837785007115599 |
| 147 | ppo | 10 | 12.89390866663721 | 0.3019410416018218 |
| 153 | ppo | 10 | 13.411405264602767 | 0.04288237243890762 |
| 155 | ppo | 10 | 13.58538499130143 | 0.15605995901860298 |
| 158 | ppo | 10 | 13.801978436642223 | 0.22465740733896383 |
| 164 | ppo | 20 | 14.314509583181804 | -0.029324072669260202 |
| 169 | ppo | 10 | 14.67261397673024 | 0.08145973170830985 |
| 199 | ppo | 10 | 17.19244692020946 | 0.37414854298112915 |
| 205 | ppo | 20 | 18.22420354962349 | 0.04500469565973617 |
| 206 | ppo | 10 | 18.296115912927522 | -0.0198094007675536 |
| 220 | ppo | 20 | 19.448718159331214 | 0.49556688376251257 |
| 231 | ppo | 20 | 20.343756362862056 | 0.14662921361668851 |
| 275 | ppo | 20 | 24.100154759817652 | 0.03868253273249138 |

A missing rotation block is inconclusive. These results select only this format.
Full gates, errors and the original budget are recorded in summary.json.
